package ph.pup.itech.comffee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserAddClass {
    
    public boolean addUser (
            String userID,
            String firstName,
            String middleName,
            String lastName,
            String userRole) throws ClassNotFoundException{
        
        boolean success = false;
        Connection conn = null;
        PreparedStatement ps = null;
        
        try{
            String query = "INSERT INTO userinfo ("
                    + "userID, "
                    + "firstName, "
                    + "middleName, "
                    + "lastName, "
                    + "accountStatus, "
                    + "loginStatus, "
                    + "userRole)"
                    + "VALUES(?, ?, ?, ?, 'Valid', 'Offline', ?)";
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, userID);
            ps.setString(2, firstName);
            ps.setString(3, middleName);
            ps.setString(4, lastName);
            ps.setString(5, userRole);
            
            
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected != 0) {
                success = true;
            }
            
            conn.close();
            
        }catch (SQLException e){
            System.out.println("SQLException: " + e);
        }finally {
            if (ps != null) {
                try {
                    ps.close();
                }
                catch (SQLException e){
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            
            if(conn != null) {
                try{
                    conn.close();
                } catch (SQLException e){
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }
        return success;
    }
    public boolean addCustomer (
            String userID,
            String passw,
            String firstName,
            String middleName,
            String lastName,
            String address,
            String birthday,
            String mobileNumber) throws ClassNotFoundException{
        
        boolean success = false;
        Connection conn = null;
        PreparedStatement ps = null;
        
        try{
            String query = "INSERT INTO userinfo ("
                    + "userID, "
                    + "passw, "
                    + "firstName, "
                    + "middleName, "
                    + "lastName, "
                    + "completeAddress, "
                    + "birthday, "
                    + "mobileNumber, "
                    + "accountStatus, "
                    + "loginStatus, "
                    + "userRole) "
                    + "VALUES(?, ?, ?, ?, ?, ?, ?, ?, 'Valid', 'Offline', 'Customer')";
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, userID);
            ps.setString(2, passw);
            ps.setString(3, firstName);
            ps.setString(4, middleName);
            ps.setString(5, lastName);
            ps.setString(6, address);
            ps.setString(7, birthday);
            ps.setString(8, mobileNumber);
            
            
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected != 0) {
                success = true;
            }
            
            conn.close();
            
        }catch (SQLException e){
            System.out.println("SQLException: " + e);
        }finally {
            if (ps != null) {
                try {
                    ps.close();
                }
                catch (SQLException e){
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            
            if(conn != null) {
                try{
                    conn.close();
                } catch (SQLException e){
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }
        return success;
    }
}
