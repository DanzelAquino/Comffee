
package ph.pup.itech.comffee.dao;

import ph.pup.itech.comffee.model.userModel;

public class userDao {
 public userModel getUserDetails (userModel user) {
     userModel userDetails;
     
     String userID = user.getUserID();
     String firstName = user.getFirstName();
     String middleName = user.getMiddleName();
     String lastName = user.getLastName();
     String accountStatus = user.getAccountStatus();
     String loginStatus = user.getLoginStatus();
     String userRole = user.getUserRole();
     
     userDetails = new userModel (userID, firstName, middleName, lastName, accountStatus, loginStatus, userRole);
     System.out.println("userDetails: " + userDetails);
     return userDetails;
 }
}
