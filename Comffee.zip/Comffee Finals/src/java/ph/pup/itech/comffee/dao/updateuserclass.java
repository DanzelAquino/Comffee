package ph.pup.itech.comffee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import ph.pup.itech.comffee.model.userModel;

public class updateuserclass {

    public ArrayList<userModel> getUserDetails(String userID) throws ClassNotFoundException {
        ArrayList<userModel> userDetails = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query = "SELECT "
                + "userID, "
                + "firstName, "
                + "middleName, "
                + "lastName, "
                + "userRole "
                + "FROM userinfo "
                + "WHERE userID = ?";

        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, userID);
            rs = ps.executeQuery();

            while (rs.next()) {
                userModel user = new userModel();
                user.setUserID(rs.getString("userID"));
                user.setFirstName(rs.getString("firstName"));
                user.setMiddleName(rs.getString("middleName"));
                user.setLastName(rs.getString("lastName"));
                user.setUserRole(rs.getString("userRole"));
                userDetails.add(user);
            }

            conn.close();

        } catch (SQLException e) {
            System.out.println("getUserDetails error: " + e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }

        return userDetails;

    }

    public boolean editUser(String userID, String firstName, String middleName, String lastName, String userRole) throws ClassNotFoundException {

        boolean success = false;
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String query = "UPDATE userinfo SET "
                    + "firstName = ?, "
                    + "middleName = ?, "
                    + "lastName = ?, "
                    + "userRole = ? "
                    + "WHERE userID = ?";
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(5, userID);
            ps.setString(1, firstName);
            ps.setString(2, middleName);
            ps.setString(3, lastName);
            ps.setString(4, userRole);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected != 0) {
                success = true;
            }

        } catch (SQLException e) {
            System.out.println("editUser error: " + e);
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }

        return success;
    }

    public boolean deleteUser(String userID) throws ClassNotFoundException {
        boolean success = false;
        
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String query = "DELETE FROM userinfo WHERE userID = ? ";
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, userID);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected != 0) {
                success = true;
            }

        } catch (SQLException e) {
            System.out.println("deleteUser error: " + e);
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }
        return success;
    }
}
