package ph.pup.itech.comffee.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ph.pup.itech.comffee.dao.UserAddClass;

import ph.pup.itech.comffee.model.customerModel;
import ph.pup.itech.comffee.dao.customerDao;

public class customer extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();

        switch (action) {
            case "/customer/registration":
                showRegistrationForm(request, response);
                break;
            default:
            {
                try {
                    getCustomer(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(customer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                break;

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void getCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException {
        if (request.getParameter("addUser") != null) {

            String userName = request.getParameter("userName");
            String password = request.getParameter("password");
            String firstName = request.getParameter("firstName");
            String middleName = request.getParameter("middleName");
            String lastName = request.getParameter("lastName");
            String address = request.getParameter("address");
            String birthday = request.getParameter("birthday");
            String mobileNumber = request.getParameter("mobileNumber");

            customerModel customer = new customerModel(userName, password, firstName, middleName, lastName, address, birthday, mobileNumber);

            customerDao customerDao = new customerDao();
            customerModel getCustomer = customerDao.getCustomerDetails(customer);

            request.setAttribute("custtomer", getCustomer);
            
            UserAddClass reg = new UserAddClass();
            boolean addCustomer = reg.addCustomer(userName, password, firstName, middleName, lastName, address, birthday, mobileNumber);

            if (userName != null) {
                if (addCustomer) {
                    String messageCustomer = " user has been added!";
                    request.setAttribute("messageCustomer", messageCustomer);
                } else {
                    String messageCustomer = "user has not been added! Database Query Error";
                    request.setAttribute("messageCustomer", messageCustomer);
                }
            }

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/customer.jsp");
            rd.forward(request, response);
        }
    }

    private void showRegistrationForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/registrationform.jsp");
        rd.forward(request, response);
    }

}
