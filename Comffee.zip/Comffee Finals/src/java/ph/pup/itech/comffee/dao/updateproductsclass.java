package ph.pup.itech.comffee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import ph.pup.itech.comffee.model.productsModel;

public class updateproductsclass {

    public ArrayList<productsModel> getProductsDetails(String productID) throws ClassNotFoundException, SQLException {
        ArrayList<productsModel> allProducts = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT "
                + "productID, "
                + "productName, "
                + "descript, "
                + "size, "
                + "price, "
                + "quantity "
                + "FROM productsinfo "
                + "WHERE productID = ?";

        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, productID);
            rs = ps.executeQuery();

            while (rs.next()) {
                productsModel products = new productsModel();
                products.setProductID(rs.getInt("productID"));
                products.setProductName(rs.getString("productName"));
                products.setDescription(rs.getString("descript"));
                products.setSize(rs.getString("size"));
                products.setPrice(rs.getDouble("price"));
                products.setQuantity(rs.getInt("quantity"));
                allProducts.add(products);
            }
            conn.close();

        } catch (SQLException e) {
            System.out.println("getProductsDetails error: " + e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }

            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }

        }
        return allProducts;

    }

    public boolean editProducts(String productID, String productName, String descript, String size, String price, String quantity) throws ClassNotFoundException {

        boolean success = false;
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String query = "UPDATE productsinfo SET "
                    + "productName = ?, "
                    + "descript = ?, "
                    + "size = ?, "
                    + "price = ?, "
                    + "quantity = ? "
                    + "WHERE productID = ?";
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(6, productID);
            ps.setString(1, productName);
            ps.setString(2, descript);
            ps.setString(3, size);
            ps.setString(4, price);
            ps.setString(5, quantity);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected != 0) {
                success = true;
            }

        } catch (SQLException e) {
            System.out.println("editProducts error: " + e);
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }

        return success;
    }

    public boolean deleteProducts(String productID) throws ClassNotFoundException {
        boolean success = false;

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String query = "DELETE FROM productsinfo WHERE productID = ? ";
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, productID);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected != 0) {
                success = true;
            }

        } catch (SQLException e) {
            System.out.println("deleteProducts error: " + e);
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }
        return success;
    }

}
