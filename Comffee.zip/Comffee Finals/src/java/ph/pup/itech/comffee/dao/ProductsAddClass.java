package ph.pup.itech.comffee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductsAddClass {

    public boolean addProducts(
            int productID,
            String productName,
            String description,
            String size,
            Double price,
            int quantity) throws ClassNotFoundException {

        boolean success = false;
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String query = "INSERT INTO productsinfo ("
                    + "productID,"
                    + "productName,"
                    + "descript,"
                    + "size,"
                    + "price,"
                    + "quantity)"
                    + "VALUES(?, ?, ?, ?, ?, ?)";
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, productID);
            ps.setString(2, productName);
            ps.setString(3, description);
            ps.setString(4, size);
            ps.setDouble(5, price);
            ps.setInt(6, quantity);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected != 0) {
                success = true;
            }
            conn.close();
        } catch (SQLException e) {
            System.out.println("SQLException: " + e);
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }
        return success;
    }
}
