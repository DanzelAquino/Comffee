package ph.pup.itech.comffee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import ph.pup.itech.comffee.model.productsModel;

public class ProductsSearchClass {

    public ArrayList<productsModel> getAllProducts() throws ClassNotFoundException {
        ArrayList<productsModel> allProducts = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            String query = "SELECT "
                    + "productID, "
                    + "productName, "
                    + "descript, "
                    + "size, "
                    + "price, "
                    + "quantity "
                    + "FROM productsinfo";

            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                productsModel products = new productsModel();
                products.setProductID(rs.getInt("productID"));
                products.setProductName(rs.getString("productName"));
                products.setDescription(rs.getString("descript"));
                products.setSize(rs.getString("size"));
                products.setPrice(rs.getDouble("price"));
                products.setQuantity(rs.getInt("quantity"));
                allProducts.add(products);
            }

            conn.close();

        } catch (SQLException e) {
            System.out.println("getAllProducts error: " + e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }

        }
        return allProducts;
    }
}
