package ph.pup.itech.comffee.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ph.pup.itech.comffee.dao.UserAddClass;
import ph.pup.itech.comffee.dao.searchuserclass;
import ph.pup.itech.comffee.dao.updateuserclass;
import ph.pup.itech.comffee.model.userModel;
import ph.pup.itech.comffee.dao.userDao;

public class user extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getServletPath();

        switch (action) {

            case "/user/create":
                showUserForm(request, response);
                break;

            case "/user/view": 
                try {
                viewUserDetails(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;

            case "/user/update":
                try {
                updateUserDetails(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;

            case "/user/delete":
                try {
                deleteUser(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;

            default: {
                try {
                    getUser(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(user.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            break;

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void getUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {

        if (request.getParameter("addUser") != null) {
            String userID = request.getParameter("userID");
            String firstName = request.getParameter("firstName");
            String middleName = request.getParameter("middleName");
            String lastName = request.getParameter("lastName");
            String accountStatus = request.getParameter("accountStatus");
            String loginStatus = request.getParameter("loginStatus");
            String userRole = request.getParameter("userRole");

            userModel user = new userModel(userID, firstName, middleName, lastName, accountStatus, loginStatus, userRole);

            userDao userDao = new userDao();
            userModel getUser = userDao.getUserDetails(user);

            request.setAttribute("user", getUser);

            UserAddClass reg = new UserAddClass();
            boolean addUser = reg.addUser(userID, firstName, middleName, lastName, userRole);

            if (userID != null) {
                if (addUser) {
                    String messageUser = " user has been added!";
                    request.setAttribute("messageUser", messageUser);
                } else {
                    String messageUser = "user has not been added! Database Query Error";
                    request.setAttribute("messageUser", messageUser);
                }
            }
        }

        searchuserclass search = new searchuserclass();
        ArrayList<userModel> allUser = search.getAllUser();
        request.setAttribute("allUser", allUser);

        RequestDispatcher rd = getServletContext().getRequestDispatcher("/users.jsp");
        rd.forward(request, response);
    }

    private void showUserForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/usersform.jsp");
        rd.forward(request, response);
    }

    private void viewUserDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {
        if (request.getParameter("viewdetails") != null) {

            String userID = request.getParameter("id");
            updateuserclass edit = new updateuserclass();
            ArrayList<userModel> userDetails = edit.getUserDetails(userID);
            request.setAttribute("userDetails", userDetails);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/usersupdate.jsp");
            rd.forward(request, response);

        }
    }

    private void updateUserDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {

        if (request.getParameter("updateUser") != null) {
            String userID = request.getParameter("userID");
            String firstName = request.getParameter("firstName");
            String middleName = request.getParameter("middleName");
            String lastName = request.getParameter("lastName");
            String userRole = request.getParameter("userRole");

            updateuserclass update = new updateuserclass();
            boolean editUser = update.editUser(userID, firstName, middleName, lastName, userRole);

            if (editUser) {
                String messageUser = " user has been updated!";
                request.setAttribute("messageUser", messageUser);
            } else {
                String messageUser = "user has not been updated! Database Query Error";
                request.setAttribute("messageUser", messageUser);
            }

            searchuserclass search = new searchuserclass();
            ArrayList<userModel> allUser = search.getAllUser();
            request.setAttribute("allUser", allUser);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/users.jsp");
            rd.forward(request, response);
        }
    }

    private void deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {

        if (request.getParameter("deleteuser") != null) {

            String userID = request.getParameter("userID");
            updateuserclass update = new updateuserclass();
            boolean deleteUser = update.deleteUser(userID);

            if (deleteUser) {
                String messageUser = " user has been deleted!";
                request.setAttribute("messageUser", messageUser);
            } else {
                String messageUser = " user has not been deleted!";
                request.setAttribute("messageUser", messageUser);
            }

            searchuserclass search = new searchuserclass();
            ArrayList<userModel> allUser = search.getAllUser();
            request.setAttribute("allUser", allUser);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/users.jsp");
            rd.forward(request, response);
        }
    }
}
