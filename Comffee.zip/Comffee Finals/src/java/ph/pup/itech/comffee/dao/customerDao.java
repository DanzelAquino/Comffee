
package ph.pup.itech.comffee.dao;

import ph.pup.itech.comffee.model.customerModel;

public class customerDao  {
    public customerModel getCustomerDetails (customerModel customer) {
        customerModel customerDetails;
        String userName = customer.getUserName();
        String password = customer.getPassword();
        String firstName = customer.getFirstName();
        String middleName = customer.getMiddleName();
        String lastName = customer.getLastName();
        String address = customer.getAddress();
        String birthday = customer.getBirthday();
        String mobileNumber = customer.getMobileNumber();
        
        customerDetails = new customerModel (userName, password, firstName, middleName, lastName, address, birthday, mobileNumber);
        System.out.println("customerDetails: " + customerDetails);
        return customerDetails;
                    
        
    }

}
