package ph.pup.itech.comffee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import ph.pup.itech.comffee.model.userModel;

public class searchuserclass {

    public ArrayList<userModel> getAllUser() throws ClassNotFoundException {
        ArrayList<userModel> allUser = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            String query = "SELECT "
                    + "userID, "
                    + "firstName, "
                    + "middleName, "
                    + "lastName, "
                    + "accountStatus, "
                    + "loginStatus, "
                    + "userRole "
                    + "FROM userinfo";

            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                userModel user = new userModel();
                user.setUserID(rs.getString("userID"));
                user.setFirstName(rs.getString("firstName"));
                user.setMiddleName(rs.getString("middleName"));
                user.setLastName(rs.getString("lastName"));
                user.setAccountStatus(rs.getString("accountStatus"));
                user.setLoginStatus(rs.getString("loginStatus"));
                user.setUserRole(rs.getString("userRole"));
                allUser.add(user);
            }

            conn.close();

        } catch (SQLException e) {
            System.out.println("getAllUser error: " + e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                }
            }
        }
        return allUser;
    }
}
