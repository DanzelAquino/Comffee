package ph.pup.itech.comffee.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ph.pup.itech.comffee.dao.ProductsAddClass;
import ph.pup.itech.comffee.dao.ProductsSearchClass;
import ph.pup.itech.comffee.model.productsModel;
import ph.pup.itech.comffee.dao.productsDao;
import ph.pup.itech.comffee.dao.updateproductsclass;

public class products extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getServletPath();

        switch (action) {

            case "/products/create":
                showProductsForm(request, response);
                break;

            case "/products/view":
                try {
                viewProductsDetails(request, response);
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(products.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;

            case "/products/update":
                try {
                updateProductsDetails(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(products.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;

            case "/products/delete":
                try {
                deleteProducts(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(products.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;

            default: {
                try {
                    getProducts(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(products.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void getProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {

        if (request.getParameter("addProducts") != null) {
            String productIDGet = request.getParameter("productID");
            String productName = request.getParameter("productName");
            String description = request.getParameter("description");
            String size = request.getParameter("size");
            String priceGet = request.getParameter("price");
            String quantityGet = request.getParameter("quantity");

            Integer productID = null;
            Double price = null;
            Integer quantity = null;

            if (priceGet != null && !priceGet.isEmpty()) {
                price = Double.parseDouble(priceGet);
            }

            if (productIDGet != null && !productIDGet.isEmpty()) {
                productID = Integer.parseInt(productIDGet);
            }

            if (quantityGet != null && !quantityGet.isEmpty()) {
                quantity = Integer.parseInt(quantityGet);
            }

            productsModel product = new productsModel(productID, productName, description, size, price, quantity);

            productsDao ProductsDao = new productsDao();
            productsModel getProducts = ProductsDao.getProductDetails(product);

            request.setAttribute("product", getProducts);

            ProductsAddClass reg = new ProductsAddClass();
            boolean addProducts = reg.addProducts(productID, productName, description, size, price, quantity);

            if (productName != null && productID != null) {
                if (addProducts) {
                    String message = "Product has been added!";
                    request.setAttribute("message", message);
                } else {
                    String message = "product has not been added!";
                    request.setAttribute("message", message);

                }
            }
        }

        ProductsSearchClass search = new ProductsSearchClass();
        ArrayList<productsModel> allProducts = search.getAllProducts();
        request.setAttribute("allProducts", allProducts);

        RequestDispatcher rd = getServletContext().getRequestDispatcher("/products.jsp");
        rd.forward(request, response);
    }

    private void showProductsForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/productform.jsp");
        rd.forward(request, response);
    }

    private void viewProductsDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        if (request.getParameter("viewdetails") != null) {

            String productID = request.getParameter("productID");
            updateproductsclass edit = new updateproductsclass();
            ArrayList<productsModel> productsDetails = edit.getProductsDetails(productID);
            request.setAttribute("productsDetails", productsDetails);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/productupdate.jsp");
            rd.forward(request, response);
        }
    }

    private void updateProductsDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {

        if (request.getParameter("updateProducts") != null) {
            String productID = request.getParameter("productID");
            String productName = request.getParameter("productName");
            String descript = request.getParameter("description");
            String size = request.getParameter("size");
            String price = request.getParameter("price");
            String quantity = request.getParameter("quantity");

            updateproductsclass update = new updateproductsclass();
            boolean editProducts = update.editProducts(productID, productName, descript, size, price, quantity);

            if (editProducts) {
                String message = "Product has been updated!";
                request.setAttribute("message", message);

            } else {
                String message = "Products has not been updated! Database Query Error";
                request.setAttribute("message", message);
            }

            ProductsSearchClass search = new ProductsSearchClass();
            ArrayList<productsModel> allProducts = search.getAllProducts();
            request.setAttribute("allProducts", allProducts);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/products.jsp");
            rd.forward(request, response);
        }
    }

    private void deleteProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {

        if (request.getParameter("deleteproducts") != null) {

            String productID = request.getParameter("productID");
            updateproductsclass update = new updateproductsclass();
            boolean deleteProducts = update.deleteProducts(productID);

            if (deleteProducts) {
                String message = "Product has been deleted!";
                request.setAttribute("message", message);
            } else {
                String message = " Product has not been deleted!";
                request.setAttribute("message", message);
            }

            ProductsSearchClass search = new ProductsSearchClass();
            ArrayList<productsModel> allProducts = search.getAllProducts();
            request.setAttribute("allProducts", allProducts);

            RequestDispatcher rd = getServletContext().getRequestDispatcher("/products.jsp");
            rd.forward(request, response);
        }

    }
}
